import baxter_interface
import rospy
import copy
from baxter_interface import CHECK_VERSION
import ik_command 
from baxter_interface.limb import *
from baxter_move_arm import *

right_iksvc, right_ns = ik_command.connect_service('right')
left_iksvc, left_ns = ik_command.connect_service('left')

initial_pos_left = (0.18168574722622946, 0.4136684594170237, -0.7116706697378603)
initial_orientation_left = (-0.5653119279593024, 0.8248492177681884, -0.00551525589903276, 0.003971650351199953)
initial_pos_right = (0.1678577208525833, -0.4202754713478438, -0.7116731321285129)
initial_orientation_right = (0.50249111543984, 0.8645600016958355, 0.005208741237856681, 0.003398733063842082)

left_0 = {'position': Limb.Point(x=0.18168574722622946, y=0.4136684594170237, z=-0.7116706697378603), 'orientation': Limb.Quaternion(x=-0.5653119279593024, y=0.8248492177681884, z=-0.00551525589903276, w=0.003971650351199953)}
right_0 = {'position': Limb.Point(x=0.1678577208525833, y=0.4202754713478438, z=-0.7116731321285129), 'orientation': Limb.Quaternion(x=-0.50249111543984, y=0.8645600016958355, z=-0.005208741237856681, w=0.003398733063842082)}
rospy.init_node("baxter_initialize_pos")
initial_pos_left = left_0['position']
initial_orientation_left = left_0['orientation']
# position = Limb.Point(x=0.22655024602559237, y=0.8385398137298931, z=-0.4074369475396944)


right = baxter_interface.Limb('right')
left = baxter_interface.Limb('left')
go_to_coordinate('right', initial_pos_right, initial_orientation_right)
go_to_coordinate('left', initial_pos_left, initial_orientation_left)
