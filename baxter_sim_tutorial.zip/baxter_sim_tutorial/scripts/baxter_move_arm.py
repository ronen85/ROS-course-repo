import baxter_interface
import rospy
import copy
from baxter_interface import CHECK_VERSION
import ik_command 
from baxter_interface.limb import *
import cords


right_iksvc, right_ns = ik_command.connect_service('right')
left_iksvc, left_ns = ik_command.connect_service('left')

def go_to_coordinate(side, position, orientation):
    if side == "left":
        iksvc = left_iksvc
    else:
        iksvc = right_iksvc
    limb = baxter_interface.Limb(side)
    coordinate_as_list = position + orientation
    print("moving to", coordinate_as_list)
    for num_try in range(10):
        ans = ik_command.service_request(iksvc, coordinate_as_list, side)
        if ans == "Invalid position requested" and num_try < 9:
            print 'Try to perform ik command again. Try number:', num_try + 1
        elif ans == "Invalid position requested" and num_try == 9:
            return
        else:
            return


def main():
    rospy.init_node("baxter_move_arm")
    side = 'left'
    go_to_coordinate(side, cords.left_1['position'], cords.left_1['orientation'])
    go_to_coordinate(side, cords.left_2['position'], cords.left_2['orientation'])
    go_to_coordinate(side, cords.left_3['position'], cords.left_3['orientation'])
    go_to_coordinate(side, cords.left_4['position'], cords.left_4['orientation'])
    go_to_coordinate(side, cords.left_5['position'], cords.left_5['orientation'])
    go_to_coordinate(side, cords.left_6['position'], cords.left_6['orientation'])
    go_to_coordinate(side, cords.left_7['position'], cords.left_7['orientation'])
    go_to_coordinate(side, cords.left_8['position'], cords.left_8['orientation'])
    go_to_coordinate(side, cords.left_9['position'], cords.left_9['orientation'])
    gripper = baxter_interface.Gripper(side, CHECK_VERSION)
    gripper.close(True)
    go_to_coordinate(side, cords.left_8['position'], cords.left_8['orientation'])
   

if __name__ == '__main__':
    main()
