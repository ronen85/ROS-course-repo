import baxter_interface
import rospy
import copy
from baxter_interface import CHECK_VERSION
import ik_command 
from baxter_interface.limb import *

right_iksvc, right_ns = ik_command.connect_service('right')
left_iksvc, left_ns = ik_command.connect_service('left')

def go_to_coordinate_new(side, position, orientation):
    if side == "left":
        iksvc = left_iksvc
    else:
        iksvc = right_iksvc
    limb = baxter_interface.Limb(side)
    coordinate_as_list = position + orientation
    print("moving to", coordinate_as_list)    
    ik_command.service_request(iksvc, coordinate_as_list, side)

def print_pose():
    rospy.init_node("baxter_print_pos")
    left = baxter_interface.Limb('left')
    right = baxter_interface.Limb('right')
    print('left',left.endpoint_pose())
    print('right',right.endpoint_pose())


def main():
    rospy.init_node("baxter_move_arm")
    position = Limb.Point(x=0.4, y=0.2, z=0.1)
    orientation = Limb.Quaternion(x=0.0, y=1, z=0, w=0.0)
    side = 'left'
    go_to_coordinate_new(side, position, orientation)
	
    

if __name__ == '__main__':
    main()
